	<footer id="colophon" class="site-footer">
	<div class="container">
		<div class="site-info">
			<h2 class="title_foot"><?php echo $blog_title; ?></h2>
			 <span>&copy; <?php echo $blog_title; ?> - All Right Reserved.</span>
			<div class="foot">
				<a href="<?php echo $url.'/p/dmca.html' ?>">DMCA</a>
				<a href="<?php echo $url.'/p/contact.html' ?>">Contact</a>
				<a href="<?php echo $url.'/p/privacy-policy.html' ?>">Privacy Policy</a>
				<a href="<?php echo $url.'/p/copyright.html' ?>">Copyright</a>
			</div>
		</div>
	</div>	
	</footer>
	<a href="#top" class="smoothup" title="Back to top"><span class="genericon genericon-collapse"></span></a>
</div>
<!-- #page -->
<script src='<?php echo $url; ?>/js/jquery.js'></script>
<script src='<?php echo $url; ?>/js/plugins.js'></script>
<script src='<?php echo $url; ?>/js/scripts.js'></script>
<script src='<?php echo $url; ?>/js/masonry.pkgd.min.js'></script>
<?php echo $counter; ?>
</body>
</html>